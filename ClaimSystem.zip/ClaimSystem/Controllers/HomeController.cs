using Microsoft.AspNetCore.Mvc;

namespace ClaimSystem.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index(string uniqueId)
        {
            if (uniqueId == "1122331") // Check for admin identifier
            {
                HttpContext.Session.SetString("UniqueId", uniqueId); // Store admin ID in session
                return RedirectToAction("ManagerDashboard", "Claims"); // Redirect to Manager Dashboard
            }
            else if (!string.IsNullOrEmpty(uniqueId))
            {
                HttpContext.Session.SetString("LecturerName", uniqueId); // Store lecturer name in session
                return RedirectToAction("LecturerDashboard", "Claims"); // Redirect to Lecturer Dashboard
            }
            return View("EnterUniqueId"); // Show unique ID input view if none is provided
        }

        // Action to display the EnterUniqueId view
        public IActionResult EnterUniqueId()
        {
            return View();
        }
    }
}
