using Microsoft.AspNetCore.Mvc;
using ClaimSystem.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace ClaimSystem.Controllers
{
    public class ClaimsController : Controller
    {
        private static List<Claim> ClaimsList = new List<Claim>();
        private const string AdminIdentifier = "1122331"; // Unique identifier for admin

        // Display the claim submission form
        public IActionResult Create()
        {
            return View();
        }

        // Handle form submission
        [HttpPost]
        public IActionResult Create(Claim claim, IFormFile file)
        {
            if (ModelState.IsValid)
            {
                // Assign an ID and add the claim to the list
                claim.Id = ClaimsList.Count + 1;

                // Handle file upload
                if (file != null && file.Length > 0)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                    var filePath = Path.Combine(uploadsFolder, file.FileName);

                    // Ensure the uploads folder exists
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    // Copy the file to the uploads folder
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                    claim.UploadedFileName = file.FileName; // Save the file name to the claim
                }
                else
                {
                    ModelState.AddModelError("UploadedFileName", "Please upload a file."); // Add error message if no file is uploaded
                }

                // If no model errors, add the claim to the list
                if (ModelState.IsValid)
                {
                    ClaimsList.Add(claim);
                    HttpContext.Session.SetString("LecturerName", claim.LecturerName); // Store lecturer name in session
                    TempData["SuccessMessage"] = "Claim submitted successfully!"; // Success message
                    
                    return RedirectToAction("LecturerDashboard"); // Redirect to lecturer dashboard
                }
            }

            // Return to the view with the current claim (with validation messages if any)
            return View(claim);
        }

        // List claims for a lecturer
        public IActionResult LecturerDashboard()
        {
            var lecturerClaims = ClaimsList.Where(c => c.LecturerName == HttpContext.Session.GetString("LecturerName")).ToList(); // Get claims for the logged-in lecturer
            return View(lecturerClaims);
        }

        // Manager dashboard to list all claims
        public IActionResult ManagerDashboard()
        {
            // Check if the user is logged in as an admin
            var uniqueId = HttpContext.Session.GetString("UniqueId"); // Get the session value
            if (uniqueId == AdminIdentifier) 
            {
                return View(ClaimsList); // Managers see all claims
            }
            return RedirectToAction("EnterUniqueId", "Home"); // Redirect if not admin
        }

        // Approve or Reject a claim
        [HttpPost]
        public IActionResult UpdateStatus(int id, string status)
        {
            var claim = ClaimsList.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.Status = status;
                TempData["SuccessMessage"] = $"Claim {id} status updated to {status}."; // Status update message
            }
            return RedirectToAction("ManagerDashboard"); // Redirect to manager dashboard
        }

        // Logout action to clear the session
        public IActionResult Logout()
        {
            // Clear all session data
            HttpContext.Session.Clear();

            // Redirect to the EnterUniqueId page
            return RedirectToAction("EnterUniqueId", "Home");
        }
    }
}
