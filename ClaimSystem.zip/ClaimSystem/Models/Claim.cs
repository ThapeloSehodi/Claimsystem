namespace ClaimSystem.Models
{
    public class Claim
    {
        public int Id { get; set; }
        public required string LecturerName { get; set; }
        public int HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public string? Notes { get; set; }
        public string Status { get; set; } = "Pending"; // Default status
        public  string? UploadedFileName { get; set; }
    }
}
